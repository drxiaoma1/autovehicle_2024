# reading Video
import cv2
import numpy as np

h = 100         #修改高度值

def main():      
    cap = cv2.VideoCapture("./record.avi")  #修改成车道线视频文件所在位置
    ret = cap.isOpened()
    cv2.namedWindow("image", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("image", 960, 224)
    
    while(ret):
        ret, frame = cap.read()
        if ret == True:
            cv2.imshow("frame",frame) 
            cropImage = frame[h:h+224,:,:].copy()
            cv2.imshow("image",cropImage)            
            k = cv2.waitKey(10)
            if( k == ord('q')):
                break 
    cv2.waitKey(0)
    cap.release()
    cv2.destroyAllWindows()
    
if __name__ == '__main__':
    main()