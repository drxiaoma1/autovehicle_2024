# reading Video
import cv2
import PIL.Image
import numpy as np
import os
import torch
import torchvision.transforms as transforms
import onnxruntime
import glob

h=100
onnx_model_path = './best_line_follower_model_xy.onnx'

data_transform = transforms.Compose(
        [transforms.Resize([224,224]),         
         transforms.ToTensor(),
         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

def pred(image):
    data = PIL.Image.fromarray(cv2.cvtColor(image,cv2.COLOR_BGR2RGB))
    data = data_transform(data)
    data = torch.unsqueeze(data, dim=0)
    data = data.numpy()

    resnet_session = onnxruntime.InferenceSession(onnx_model_path)
    input_name = resnet_session.get_inputs()[0].name
    out_name = resnet_session.get_outputs()[0].name
    pred_onx = resnet_session.run([out_name], {input_name:data}) # 执行推断

    xx=int((pred_onx[0][0][0]+1)*640)
    yy=int((pred_onx[0][0][1]+1)*112)
    return(xx,yy)


def main():  
    cap = cv2.VideoCapture("./record.avi")
    ret = cap.isOpened()    
    while(ret):
        ret, frame = cap.read()
        if ret == True:            
            cropImage = frame[h:h+224,:,:].copy()
            x1,y1 = pred(cropImage)
            frame = cv2.circle(frame, (x1,y1+h), 20, (0,0,255), -1)  
            cv2.imshow("frame",frame)
            k = cv2.waitKey(5)            
            if( k == ord('q')):
                break            
    cv2.waitKey(0)
    cap.release()
    cv2.destroyAllWindows()
    
if __name__ == '__main__':
    main()